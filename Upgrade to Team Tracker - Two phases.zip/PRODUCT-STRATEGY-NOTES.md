# Product Strategy Notes

> Captured from the brainstorm. Not implementation guidance — this is
> the "what is this app even" reflection that came up alongside the
> technical work.

---

## What's Actually Distinctive

The youth sports app market is owned at the top by TeamSnap and
SportsEngine — generic logistics tools for scheduling, RSVPs,
payments, messaging. Competing with them head-on is not viable for a
solo developer.

The Kaizen Tracker is **not** trying to be that. It's a different
product solving a different problem:

- **A motivational tool for players** (vs. a logistics tool for parents)
- Built around a specific coaching philosophy (Kaizen / continuous
  improvement)
- Engagement-focused metrics: attendance, streaks, recognition
- A prize wheel as a first-class reward mechanism
- Reports oriented to coach-to-player insight ("who needs follow-up")

That narrowness is the asset. A small but devoted user base of
philosophy-aligned coaches is a viable target. A general-purpose tool
trying to out-feature TeamSnap is not.

---

## Realistic Revenue Targets

Putting numbers to "small monthly income":

**$500/month MRR** (development tools + hosting + small reward for
effort):
- ~50 paying coaches at $10/month
- ~20 paying orgs at $25/month
- ~10 paying clubs at $50/month

**Time to reach $500/month after launch:** Most likely 12-18 months
of consistent part-time effort, with strong word-of-mouth or niche
community traction.

**$5,000/month MRR** would require either:
- A significant pivot toward direct competition with TeamSnap
- Going upmarket to multi-program clubs (a different product)
- A breakthrough viral moment (unpredictable, can't plan for)

Neither is realistic for this app's current direction without major
changes.

---

## Highest-Leverage Future Features (Beyond This Brief)

If turning this into a small business becomes a real goal, these are
the features most likely to move the needle:

### 1. Parent-facing progress reports (high impact)

A weekly or monthly summary email/PDF to parents showing their kid's
attendance, streaks, recognition. This:

- Creates a feedback loop that increases parent buy-in
- Increases retention (parents nudge kids to keep showing up)
- Creates word-of-mouth (parents talk to other parents)
- Plays into the "coaching philosophy" positioning — coaches who use
  the app deliver something parents actively appreciate

**Cost:** Adds VPC/COPPA scope; needs parent email collection and
consent workflow. But it's a one-way report (no collection from
parents) which keeps the consent flow lighter.

### 2. Free tier limited to one squad (monetization hook)

Single-team coaches use free forever. Multi-squad org directors hit
the paywall. The squad architecture you're building enables exactly
this monetization model — Phase 2 lays the foundation.

### 3. Templates / starter content

"Set up your first squad in 90 seconds" with grade and color presets,
sample event types, etc. The activation barrier is real — most new
users abandon during setup.

### 4. Coaching philosophy as the marketing hook

The first-page-of-the-website should sell the **approach**, not the
feature list. "The Kaizen Method tracker for youth basketball — built
on the philosophy of small daily improvements." Coaches who buy into
the philosophy buy the tool.

### 5. Player-facing view (longer-term)

A stripped-down view where kids see their own streaks, standing,
recent recognition. Creates an in-app pull. Crosses into COPPA-VPC
territory but unlocks the most engagement growth.

---

## Distribution Reality Check

The hard part is not building the app. It's people finding out it
exists. Youth basketball coaches are a fragmented audience:

- No Product Hunt for them
- Reachable through: coaching clinics, AAU forums, basketball Twitter,
  podcast guest appearances, word-of-mouth from your own program
- Free TeamSnap is the default and has inertia
- Cheap (free Google Sheets, Discord)

If you're serious about this beyond a learning project, plan to spend
**at least as much time on distribution as on the app itself.** Most
side-project SaaS that achieves any revenue gets there through
relentless outreach to a specific community, not viral growth.

---

## Why Build It Anyway

The honest answer: **the learning is the return**, regardless of
revenue.

Building this teaches:
- Multi-tenant data modeling
- Real-world auth and RLS
- Privacy compliance (COPPA, eventually GDPR)
- Product decision-making with real users
- Iterative refactoring without breaking production

That's professionally valuable independent of whether 30 strangers
ever pay $10 a month. Most software careers benefit from having shipped
something end-to-end at small scale, and this project is exactly that.

The downside is small (your time, which you're spending on learning
anyway) and the upside is real even if modest. Build it well, charge
a fair price when ready, see what happens, and don't quit your day
job for it.

---

## Concrete Pre-Launch Action

If you ever decide to take this beyond a personal tool:

1. **Lock down a domain.** "Kaizen Tracker", "Kaizen Coach", or
   whatever variant feels right. Costs $12/year. Worth doing now
   even if launch is far away.
2. **Reserve the social handles.** Same logic.
3. **Write a landing page.** Even if the product isn't ready,
   articulate what it is and let coaches express interest. Captures
   email addresses for the eventual launch.
4. **Use it in your own program.** The single best validation. If
   you don't use it yourself, no one will.
5. **Find three other coaches in your network.** Get them using it
   free in exchange for feedback. Their pain points shape v3 better
   than any market research.

None of this needs to happen now. But none of it gets easier later.
