# Phase 2: Squads, COPPA Alignment & Raffle History

> Adds the squad model, structured player identity fields aligned with
> COPPA's data minimization principle, anonymizing player deletion, and
> database-backed raffle winner history. Builds on Phase 1's multi-tenancy
> foundation.

---

## Prerequisites

**Phase 1 must be complete and stable before starting Phase 2.** Verify:

- Multi-tenancy is working end-to-end
- Organization invitations work
- RLS policies are correctly scoped by organization
- No regressions in existing functionality
- You've used the app for at least a few sessions to surface any
  Phase 1 issues

---

## Goal

Three intertwined feature changes that share a migration:

1. **Squads** — sub-teams within an organization, with structured
   grade or age grouping
2. **COPPA alignment** — structured player name fields and anonymizing
   deletion procedure
3. **Raffle history** — move from localStorage to database, with
   CASCADE deletion

**Success criterion:** A head coach can create multiple squads, assign
players to them, take attendance for one or many squads at once, and
have all reports/leaderboard/raffle correctly scope by squad. Deleting
a player anonymizes them across all data.

---

## Schema Changes

A single new migration: `migrations/012_squads_coppa_raffle.sql`.

### Data Wipe (Destructive)

Per the brainstorm: existing data is test data and is being wiped.
This is the destructive part of the migration.

```sql
-- ============================================================
-- 012_squads_coppa_raffle.sql
-- WARNING: This migration WIPES roster, events, active_session,
-- and archived_event_sets data. Existing data is test data only.
-- Subsequent re-runs find empty tables (effectively no-op).
-- ============================================================

TRUNCATE TABLE public.roster CASCADE;
TRUNCATE TABLE public.events CASCADE;
TRUNCATE TABLE public.active_session CASCADE;
TRUNCATE TABLE public.archived_event_sets CASCADE;
-- DO NOT truncate organizations, organization_members, team_settings,
-- activity_log, or any phase-1 tables.
```

### New Squads Table

```sql
CREATE TABLE IF NOT EXISTS public.squads (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  name            TEXT NOT NULL CHECK (char_length(name) BETWEEN 1 AND 60),
  description     TEXT CHECK (char_length(description) <= 280),

  grouping        TEXT NOT NULL DEFAULT 'grade'
                  CHECK (grouping IN ('grade', 'age', 'mixed')),

  -- Grade fields: populated when grouping = 'grade'
  -- 0 = Kindergarten, 1 = 1st grade, ..., 12 = 12th grade
  grade_min       SMALLINT CHECK (grade_min BETWEEN 0 AND 12),
  grade_max       SMALLINT CHECK (grade_max BETWEEN 0 AND 12),

  -- Age field: populated when grouping = 'age'
  -- 12 displays as "12U" (under 12)
  age_max         SMALLINT CHECK (age_max BETWEEN 4 AND 18),

  color           TEXT,  -- hex or palette key
  sort_order      INT NOT NULL DEFAULT 0,
  archived_at     TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT squad_org_name_unique UNIQUE (organization_id, name),
  CONSTRAINT grouping_fields_match CHECK (
    (grouping = 'grade' AND grade_min IS NOT NULL AND grade_max IS NOT NULL
                       AND grade_min <= grade_max AND age_max IS NULL)
    OR
    (grouping = 'age'   AND age_max IS NOT NULL
                       AND grade_min IS NULL AND grade_max IS NULL)
    OR
    (grouping = 'mixed' AND grade_min IS NULL AND grade_max IS NULL AND age_max IS NULL)
  )
);

CREATE INDEX IF NOT EXISTS squads_organization_id_idx
  ON public.squads(organization_id);
CREATE INDEX IF NOT EXISTS squads_archived_idx
  ON public.squads(organization_id, archived_at)
  WHERE archived_at IS NULL;

-- RLS
ALTER TABLE public.squads ENABLE ROW LEVEL SECURITY;

CREATE POLICY "members_can_read_squads" ON public.squads
  FOR SELECT USING (public.is_org_member(organization_id));

CREATE POLICY "managers_can_insert_squads" ON public.squads
  FOR INSERT WITH CHECK (public.can_manage_org(organization_id));

CREATE POLICY "managers_can_update_squads" ON public.squads
  FOR UPDATE USING (public.can_manage_org(organization_id));

-- Note: no DELETE policy. Squads are soft-archived via UPDATE,
-- never hard-deleted.
```

### Roster Refactor

The existing roster table loses its `name` column and `is_guest`
column. Gains structured fields, a squad pointer, and status enum.

```sql
-- Drop old columns
ALTER TABLE public.roster
  DROP COLUMN IF EXISTS name,
  DROP COLUMN IF EXISTS is_guest;

-- Add new structured fields
ALTER TABLE public.roster
  ADD COLUMN IF NOT EXISTS first_name TEXT NOT NULL
    CHECK (char_length(first_name) BETWEEN 1 AND 30) DEFAULT 'Player',
  ADD COLUMN IF NOT EXISTS last_initial TEXT NOT NULL
    CHECK (last_initial ~ '^[A-Z]$') DEFAULT 'X',
  ADD COLUMN IF NOT EXISTS nickname TEXT
    CHECK (nickname IS NULL OR char_length(nickname) BETWEEN 1 AND 20),
  ADD COLUMN IF NOT EXISTS squad_id UUID
    REFERENCES public.squads(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS roster_status TEXT NOT NULL DEFAULT 'member'
    CHECK (roster_status IN ('member', 'visitor', 'archived'));

-- Once defaults are no longer needed for backfill, drop them:
ALTER TABLE public.roster
  ALTER COLUMN first_name DROP DEFAULT,
  ALTER COLUMN last_initial DROP DEFAULT;

-- Index for squad lookups
CREATE INDEX IF NOT EXISTS roster_squad_id_idx
  ON public.roster(squad_id) WHERE squad_id IS NOT NULL;

-- Index for active (non-archived) players
CREATE INDEX IF NOT EXISTS roster_active_idx
  ON public.roster(organization_id, roster_status)
  WHERE roster_status <> 'archived';

-- Constraint: visitors must have NULL squad_id; members must have a
-- non-NULL squad_id; archived can be either.
ALTER TABLE public.roster
  ADD CONSTRAINT roster_status_squad_consistency CHECK (
    (roster_status = 'member' AND squad_id IS NOT NULL)
    OR
    (roster_status = 'visitor' AND squad_id IS NULL)
    OR
    (roster_status = 'archived')
  );
```

### Events Refactor

```sql
-- Drop the old name-based player tracking
ALTER TABLE public.events
  DROP COLUMN IF EXISTS players;

-- Add the new arrays
ALTER TABLE public.events
  ADD COLUMN IF NOT EXISTS squad_ids JSONB NOT NULL DEFAULT '[]'
    CHECK (jsonb_typeof(squad_ids) = 'array'),
  ADD COLUMN IF NOT EXISTS player_ids JSONB NOT NULL DEFAULT '[]'
    CHECK (jsonb_typeof(player_ids) = 'array');

-- Index for "events involving squad X" queries
CREATE INDEX IF NOT EXISTS events_squad_ids_gin_idx
  ON public.events USING GIN (squad_ids);
CREATE INDEX IF NOT EXISTS events_player_ids_gin_idx
  ON public.events USING GIN (player_ids);

-- Same for active_session
ALTER TABLE public.active_session
  DROP COLUMN IF EXISTS players;

ALTER TABLE public.active_session
  ADD COLUMN IF NOT EXISTS squad_ids JSONB NOT NULL DEFAULT '[]'
    CHECK (jsonb_typeof(squad_ids) = 'array'),
  ADD COLUMN IF NOT EXISTS player_ids JSONB NOT NULL DEFAULT '[]'
    CHECK (jsonb_typeof(player_ids) = 'array');
```

### Raffle Winners Table

```sql
CREATE TABLE IF NOT EXISTS public.raffle_winners (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  player_id       UUID NOT NULL REFERENCES public.roster(id) ON DELETE CASCADE,
  squad_id        UUID REFERENCES public.squads(id) ON DELETE SET NULL,
  won_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  prize_label     TEXT CHECK (prize_label IS NULL OR char_length(prize_label) <= 100),
  scope_squad_ids JSONB NOT NULL DEFAULT '[]'
    CHECK (jsonb_typeof(scope_squad_ids) = 'array'),
  spun_by         UUID REFERENCES auth.users(id)
);

CREATE INDEX IF NOT EXISTS raffle_winners_organization_id_idx
  ON public.raffle_winners(organization_id, won_at DESC);
CREATE INDEX IF NOT EXISTS raffle_winners_player_id_idx
  ON public.raffle_winners(player_id);

-- RLS
ALTER TABLE public.raffle_winners ENABLE ROW LEVEL SECURITY;

CREATE POLICY "members_can_read_raffle_winners" ON public.raffle_winners
  FOR SELECT USING (public.is_org_member(organization_id));

CREATE POLICY "members_can_insert_raffle_winners" ON public.raffle_winners
  FOR INSERT WITH CHECK (public.is_org_member(organization_id));

-- No update or delete policy: winner history is immutable (except by
-- CASCADE when a player is deleted).
```

### purge_player Stored Procedure

```sql
CREATE OR REPLACE FUNCTION public.purge_player(p_player_id UUID)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_org_id UUID;
BEGIN
  -- Look up the player's organization
  SELECT organization_id INTO v_org_id FROM public.roster WHERE id = p_player_id;

  IF v_org_id IS NULL THEN
    RAISE EXCEPTION 'Player % not found', p_player_id;
  END IF;

  -- Authorize: only managers can purge players
  IF NOT public.can_manage_org(v_org_id) THEN
    RAISE EXCEPTION 'Not authorized to purge players in organization %', v_org_id;
  END IF;

  -- Anonymize the roster row
  UPDATE public.roster
  SET
    first_name = 'Deleted',
    last_initial = 'X',
    nickname = NULL,
    squad_id = NULL,
    roster_status = 'archived',
    updated_at = now()
  WHERE id = p_player_id;

  -- CASCADE deletes raffle_winners rows automatically via FK ON DELETE CASCADE
  -- ... but we need to delete those rows explicitly since we're not deleting
  -- the roster row itself.
  DELETE FROM public.raffle_winners WHERE player_id = p_player_id;

  -- Log the purge (without PII)
  INSERT INTO public.activity_log (
    organization_id, user_id, action, target_type, target_id, metadata
  ) VALUES (
    v_org_id,
    auth.uid(),
    'player_purged',
    'roster',
    p_player_id,
    jsonb_build_object('reason', 'parent_deletion_request')
  );
END;
$$;

GRANT EXECUTE ON FUNCTION public.purge_player(UUID) TO authenticated;
```

### Update Atomic RPCs

Every RPC in migration 003 (and any added in Phase 1) that touches
roster or events needs updating to use the new fields:

- `save_session` — accepts `squad_ids` and `player_ids` arrays instead
  of player names
- Any "add player" RPC — accepts `first_name`, `last_initial`,
  `nickname`, `squad_id`, `roster_status`
- Any reporting RPC — joins through `player_ids` UUID array instead of
  matching name strings

### Admin View Update

Re-update the admin organization summary view to include squad count:

```sql
CREATE OR REPLACE VIEW public.admin_organization_summary_view AS
SELECT
  o.id AS organization_id,
  o.name AS organization_name,
  o.created_at,
  (SELECT COUNT(*) FROM public.organization_members WHERE organization_id = o.id) AS member_count,
  (SELECT COUNT(*) FROM public.squads WHERE organization_id = o.id AND archived_at IS NULL) AS active_squad_count,
  (SELECT COUNT(*) FROM public.roster WHERE organization_id = o.id AND roster_status <> 'archived') AS active_player_count,
  (SELECT COUNT(*) FROM public.events WHERE organization_id = o.id) AS event_count,
  (SELECT MAX(saved_at) FROM public.events WHERE organization_id = o.id) AS last_event_at
FROM public.organizations o;
```

---

## Frontend Changes

### Squad Display Formatter

A single helper that produces consistent squad labels everywhere:

```typescript
// src/lib/squads/format.ts

const GRADE_LABELS = ['K', '1st', '2nd', '3rd', '4th', '5th', '6th',
                      '7th', '8th', '9th', '10th', '11th', '12th'];

export function formatSquadLabel(squad: Squad): string {
  switch (squad.grouping) {
    case 'grade': {
      const min = GRADE_LABELS[squad.grade_min];
      const max = GRADE_LABELS[squad.grade_max];
      if (squad.grade_min === squad.grade_max) {
        return squad.grade_min === 0
          ? `${min} ${squad.name}`              // "K Blue"
          : `${min} Grade ${squad.name}`;       // "7th Grade Blue"
      }
      return `${min}–${max} Grade ${squad.name}`;  // "5th–6th Grade Elite"
    }
    case 'age':
      return `${squad.age_max}U ${squad.name}`;    // "12U Elite"
    case 'mixed':
      return squad.name;                            // "Elite"
  }
}

// Compact version for badges, dropdowns
export function formatSquadCompact(squad: Squad): string {
  switch (squad.grouping) {
    case 'grade':
      return `${GRADE_LABELS[squad.grade_min]} ${squad.name}`;
    case 'age':
      return `${squad.age_max}U ${squad.name}`;
    case 'mixed':
      return squad.name;
  }
}
```

### Player Display Formatter

```typescript
// src/lib/roster/format.ts

export function formatPlayerName(player: Roster): string {
  if (player.nickname) {
    return player.nickname;
  }
  return `${player.first_name} ${player.last_initial}.`;
}
```

### Squad Management UI

New section: **Settings → Squads** (visible to Owner and Head Coaches).

- List of active squads, sorted by grouping ascending then name
- "+ Create Squad" button
- For each squad: name (formatted), member count, "Edit", "Archive"
- Section at the bottom: "Archived Squads" (collapsed by default)

### Create/Edit Squad Form

Fields:

1. **Name** (text input, required)
2. **Grouping** (radio: Grade / Age / Mixed)
   - Pre-selected to `organizations.squad_grouping_default`
3. **Grade fields** (visible when Grouping = Grade)
   - "Grade level" dropdown (single grade)
   - "Grade range" toggle → exposes min and max dropdowns
4. **Age field** (visible when Grouping = Age)
   - "Age group" dropdown: 8U, 10U, 12U, 14U, 16U, 18U + Custom
5. **Color** (palette of 10 preset swatches + Custom hex)
6. **Description** (optional textarea)

On save, validate via the CHECK constraint logic client-side too:
grade fields filled iff grouping=grade, etc.

### Settings → General: Squad Grouping Default

A new radio control in the general settings:

> **Default for new squads:**
> ○ Grade  ○ Age  ○ Mixed

This sets `organizations.squad_grouping_default`. Changing it only
affects future new squads.

### Add Player Form Changes

The existing add-player UI captures one name field. Refactor to:

1. **First name** (text input, required)
2. **Last initial** (single-letter input with auto-uppercase and
   validation, required)
3. **Nickname** (optional, with help text: "Use this for kids who go
   by a different name, or to distinguish two players with the same
   first name + initial")
4. **Squad** (dropdown, required for `roster_status = 'member'`; can
   be set to "No squad (visitor)")
5. **Helper text under the name fields:** "We only collect first
   names and last initials to protect player privacy."

### Roster List Changes

- Display players using `formatPlayerName()`
- Show squad badge next to each player (color from squad)
- Filter by squad chips at the top (multi-select)
- Hide archived players (`roster_status = 'archived'`) by default;
  add a "Show archived" toggle in advanced settings

### Quick Start (Attendance) Flow

1. Coach taps "Quick Start"
2. **New: Squad selector screen.** Multi-select chips showing all
   active squads. "Select all" affordance for all-org events. Empty
   on first load — coach picks every time, no default.
3. Coach selects 1+ squads → proceeds to attendance screen
4. **Attendance screen layout:**
   - Header: shows the selected squad names (e.g., "7th Blue +
     5th Gray")
   - **Expected players section:**
     - If 1 squad: flat alphabetical list, no group header
     - If 2+ squads: grouped by squad with collapsible squad headers
     (showing squad color), squads sorted by grade/age ascending
   - **Guest section (always visible at bottom):**
     - Search field labeled "Add a guest..."
     - Searches across the entire organization's roster
     - Each result shows player name + a small badge with their
       squad (e.g., "Marcus J. [7th Blue]")
     - Tapping a result adds them to the event as a guest
     - If no match: "+ Add new player 'Marcus Johnson'" with options
       "Add as one-time visitor" or "Add and assign to a squad"

### Leaderboard

- Default scope: org-wide (all squads)
- Filter chip at top: "All Squads" → opens multi-select
- When filtered to specific squads: attendance is computed from
  events where any of those squads appear in `events.squad_ids`,
  regardless of the player's current squad
- Archived players excluded
- Each player row shows their squad as a small colored badge

### Dashboard Podium

- Same scope rules as leaderboard (org-wide default, filterable)
- Shows top 3 with squad badges

### Reports

- Org-wide default with squad filter
- KPIs (total events, hours, etc.) respect the filter
- Session log shows squad badges per row
- CSV export includes:
  - `player_display_name` (formatted via `formatPlayerName`)
  - `squad_name` (current squad)
  - `roster_status`
  - All previous columns

### Prize Wheel

- Coach selects scope per spin: multi-select chip "Which squads are
  in this spin?"
  - Default: all squads
  - Coach can pick any subset
- "Recent winners" exclusion now reads from `raffle_winners` table
  scoped to the same squads, last 30 days
- After a spin: insert row into `raffle_winners` with
  `scope_squad_ids` set to the selected squads

### localStorage Cleanup

On app boot, run a one-time cleanup:

```typescript
// src/lib/cleanup/localStorage.ts

export function cleanLegacyLocalStorage() {
  // Remove old keys that may contain stale data from the pre-DB raffle history
  const legacyKeys = [
    'kaizen.raffleHistory',
    'kaizen.recentWinners',
    'kaizen.lastSpin',
    // add any others that the existing app uses
  ];

  for (const key of legacyKeys) {
    try {
      localStorage.removeItem(key);
    } catch {
      // localStorage may be unavailable; ignore
    }
  }
}
```

Call this once on app initialization after the user is signed in.

### Player Deletion UI

When a manager deletes a player:

1. Show confirmation modal: "Delete {player name}? This will remove
   all personal information from our records. Their attendance
   history will be preserved anonymously for statistical accuracy.
   This cannot be undone."
2. On confirm, call `purge_player(player_id)` RPC
3. Show toast: "Player anonymized"
4. Refresh roster list (the player disappears since archived players
   are hidden)

### Privacy Policy / Consent Notice

Update or add `PRIVACY.md` in the repo root with:

- What's collected (first name + initial only, plus attendance data)
- Why (program participation tracking)
- How long it's kept (until deletion request or program end)
- How to request deletion (contact head coach)
- The anonymization process (UUIDs preserved, PII stripped)
- Encryption posture (HTTPS in transit, Supabase default at rest)
- COPPA stance (we rely on the internal-operations exemption; data is
  used only for program operations)

---

## TypeScript Type Updates

```typescript
// src/types/squad.ts

export type SquadGrouping = 'grade' | 'age' | 'mixed';

export interface Squad {
  id: string;
  organization_id: string;
  name: string;
  description: string | null;
  grouping: SquadGrouping;
  grade_min: number | null;
  grade_max: number | null;
  age_max: number | null;
  color: string | null;
  sort_order: number;
  archived_at: string | null;
  created_at: string;
  updated_at: string;
}
```

```typescript
// src/types/roster.ts (updated)

export type RosterStatus = 'member' | 'visitor' | 'archived';

export interface RosterPlayer {
  id: string;
  organization_id: string;
  first_name: string;
  last_initial: string;
  nickname: string | null;
  squad_id: string | null;
  roster_status: RosterStatus;
  created_at: string;
  updated_at: string;
}
```

```typescript
// src/types/event.ts (updated)

export interface Event {
  id: string;
  organization_id: string;
  date: string;
  type: string;
  duration_minutes: number;
  squad_ids: string[];     // was: not present
  player_ids: string[];    // was: players: string[] (names)
  saved_at: string;
}
```

```typescript
// src/types/raffle.ts (new)

export interface RaffleWinner {
  id: string;
  organization_id: string;
  player_id: string;
  squad_id: string | null;
  won_at: string;
  prize_label: string | null;
  scope_squad_ids: string[];
  spun_by: string | null;
}
```

---

## File-by-File Task List

When handing this to Claude Code, work in roughly this order:

1. **`migrations/012_squads_coppa_raffle.sql`** — the migration
2. **`migrations/README.md`** — add 012
3. **`src/types/squad.ts`** — new type
4. **`src/types/roster.ts`** — updated type
5. **`src/types/event.ts`** — updated type
6. **`src/types/raffle.ts`** — new type
7. **`src/lib/squads/format.ts`** — display formatters
8. **`src/lib/roster/format.ts`** — player name formatter
9. **`src/lib/cleanup/localStorage.ts`** — legacy cleanup
10. **`src/lib/squads/api.ts`** — CRUD helpers
11. **`src/lib/raffle/api.ts`** — winners CRUD
12. **`src/lib/roster/purge.ts`** — calls `purge_player` RPC
13. **`src/app/settings/squads.tsx`** — squad management page
14. **`src/app/settings/squad-form.tsx`** — create/edit form
15. **`src/app/settings/general.tsx`** — add squad_grouping_default
    radio
16. **`src/app/roster/*`** — refactor add/edit player form, list
17. **`src/app/attendance/squad-selector.tsx`** — pre-attendance step
18. **`src/app/attendance/*`** — refactor expected/guest sections
19. **`src/app/dashboard/podium.tsx`** — squad-aware podium
20. **`src/app/leaderboard/*`** — org-wide with filter
21. **`src/app/reports/*`** — filter and CSV updates
22. **`src/app/raffle/*`** — squad scope picker, DB-backed history
23. **`PRIVACY.md`** — privacy policy update

---

## Acceptance Criteria

- [ ] The migration runs cleanly and wipes only the expected tables
- [ ] A head coach can create a squad with grade grouping
- [ ] A head coach can create a squad with age grouping
- [ ] A head coach can create a squad with mixed grouping (no grade
      or age data)
- [ ] The grade/age fields validate via CHECK constraint — bad
      combinations are rejected by the DB
- [ ] Squad display label is consistent everywhere ("7th Grade Blue",
      "12U Elite", "Elite")
- [ ] A head coach can archive a squad after moving players off it
- [ ] Archived squads do not appear in active dropdowns
- [ ] An archived squad is restorable (un-archive)
- [ ] Adding a new player requires first name + last initial; last
      initial accepts only a single uppercase letter
- [ ] Players can have an optional nickname which is used as the
      display name when present
- [ ] A player can be added with no squad (`roster_status = 'visitor'`)
- [ ] A player with a squad has `roster_status = 'member'`
- [ ] Quick Start always shows the squad selector before attendance
- [ ] Attendance screen groups expected players by squad iff 2+
      squads are selected
- [ ] The guest search finds players from any squad and shows their
      squad badge
- [ ] Adding a new player as a one-time visitor creates a roster row
      with `squad_id = NULL` and `roster_status = 'visitor'`
- [ ] Leaderboard defaults to org-wide and has a working squad filter
- [ ] When the squad filter is active, attendance is computed from
      events where that squad is in `events.squad_ids`
- [ ] Reports CSV export includes squad and roster_status columns
- [ ] Prize wheel has a per-spin squad scope picker
- [ ] After a spin, a row is inserted into `raffle_winners`
- [ ] The "exclude recent winners" feature reads from
      `raffle_winners` and respects the scope
- [ ] Deleting a player anonymizes their roster row (first_name =
      'Deleted', last_initial = 'X', nickname cleared,
      roster_status = 'archived')
- [ ] Deleted players' raffle_winners rows are removed
- [ ] Anonymized players do not appear in the leaderboard, podium,
      or reports
- [ ] Anonymized players' attendance still counts in event-level
      reports (the player_id is still in `events.player_ids` arrays)
- [ ] The activity log records each purge
- [ ] localStorage legacy keys are cleaned on app boot
- [ ] PRIVACY.md is updated and accurate

---

## Notes & Caveats for Claude Code

- **TRUNCATE is destructive.** The migration wipes test data
  intentionally. If anyone has been using the app with real data,
  STOP and revisit before running.
- **The check constraint on `roster.roster_status_squad_consistency`
  is strict.** During the migration's intermediate state (between
  adding columns and setting NOT NULL), be careful about insert
  ordering.
- **`is_org_member` and `can_manage_org` helper functions from Phase 1
  are reused** in all the new RLS policies. Don't recreate them.
- **The squad sort order is computed in queries.** Don't rely on
  insertion order. Apply the sort: `ORDER BY grouping <> 'mixed' DESC,
  grade_min ASC NULLS LAST, age_max ASC NULLS LAST, sort_order ASC,
  name ASC`. (Mixed sorts last; grade/age sorts ascending.)
- **Guest search must work across squads.** A common bug would be
  scoping the search to only the currently selected squads. The
  search must hit the entire organization's roster.
- **Anonymized players need to stay invisible in the UI but valid in
  the data.** Filter by `roster_status <> 'archived'` everywhere
  user-facing. Don't filter in queries that compute statistics from
  event arrays — the UUIDs are still meaningful there.
- **The migration drops `events.players` (the old name array).** Any
  existing code that reads from this column will break. Grep for
  `\.players[^_]` (to avoid matching `player_ids` and similar) before
  starting, and update everything.
- **Test the purge_player function thoroughly.** It's security-
  sensitive. Verify that:
  - Members of other orgs cannot call it on your players
  - Assistant coaches cannot call it (only managers can)
  - The anonymized row has all the right fields cleared
  - raffle_winners rows are gone
  - activity_log captures the action
- **The "recent winners exclusion" feature timing.** Decide whether
  "30 days" is exposed as a setting or hardcoded. Default to
  hardcoded 30 days unless you want a setting.
- **The org's `squad_grouping_default` is set in Phase 1's
  organizations table.** When a new org is created in Phase 1,
  default it to `'grade'`. The UI control just changes it.
