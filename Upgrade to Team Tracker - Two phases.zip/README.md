# Kaizen Tracker — Multi-Tenancy, Squads & COPPA Implementation Brief

> Implementation plan for transforming the Kaizen Tracker from a single-coach app
> into a multi-coach, multi-squad organization with COPPA-aligned data handling.
> Designed to be handed to Claude Code in two sequential phases.

---

## Executive Summary

**What this package is.** A two-phase implementation brief for a substantial
refactor of the Kaizen Tracker app. Phase 1 introduces multi-tenancy
(organizations + assistant coach invitations). Phase 2 introduces the squads
model, COPPA-aligned data structures, and database-backed raffle history.

**Why two phases.** The combined work is too large to land in a single change
safely. Phase 1 establishes a working multi-tenant foundation that you can
verify in isolation before Phase 2 builds the new feature work on top of it.
You can pause for weeks or months between phases.

**Starting state.** Single-coach app, all data scoped by `coach_id`. Players
stored as free-text names with an `is_guest` boolean. Events store player
names as a JSONB string array. Raffle "recent winners" history lives in
browser localStorage. All existing data will be wiped at the start of
Phase 2 (confirmed to be test data only).

**Ending state.** Multi-tenant app where users belong to organizations via a
membership table with one of three roles (Owner, Head Coach, Assistant
Coach). Coaches manage multiple squads (age- or grade-grouped sub-teams).
Players have structured first-name-plus-initial fields with optional
nicknames. Events belong to one or more squads and reference players by UUID.
Player deletion anonymizes in place. Raffle winner history is database-backed
and CASCADE-deletes with the player.

**Key decisions already made.** All open questions from the brainstorm have
been resolved. See `DECISIONS.md` for the full list with rationale.

**Status.** Not started. Both phase briefs are complete and ready to hand to
Claude Code when you're ready to implement.

---

## Quick Resume Guide

If you're returning to this project after time away, here's what to read in
order to get back up to speed in 10 minutes:

1. **This README** — the big picture (you're reading it now)
2. **`DECISIONS.md`** — every choice we made and why
3. **`PHASE1-ORGANIZATIONS-BRIEF.md`** — the foundation work (multi-tenancy)
4. **`PHASE2-SQUADS-COPPA-BRIEF.md`** — the feature work (squads + COPPA + raffle)
5. **`HANDOFF-TO-CLAUDE-CODE.md`** — how to actually start the implementation

If you're ready to implement, jump straight to `HANDOFF-TO-CLAUDE-CODE.md`.

---

## What's in this Package

```
kaizen-multitenancy-brief/
├── README.md                           ← you are here
├── DECISIONS.md                        ← every locked-in decision with rationale
├── PHASE1-ORGANIZATIONS-BRIEF.md       ← multi-tenancy foundation
├── PHASE2-SQUADS-COPPA-BRIEF.md        ← squads, COPPA, raffle history
├── HANDOFF-TO-CLAUDE-CODE.md           ← how to use this with Claude Code
└── PRODUCT-STRATEGY-NOTES.md           ← market notes and monetization thoughts
```

---

## Phase 1: Multi-Tenancy Foundation

**Goal:** Transform the app from single-coach to multi-coach without
introducing any new user-facing features. After Phase 1 the app does
everything it did before, but data is scoped by organization rather than
coach, and a head coach can invite assistant coaches.

**Adds:**
- `organizations` table (the org-level container)
- `organization_members` table (who belongs to which org and in what role)
- `organization_invitations` table (pending invites with secure tokens)
- Onboarding flow: "Start a new organization" vs "Join with an invite link"
- Settings → Members section for inviting and managing coaches
- Invite acceptance landing page with strict email matching
- Ownership transfer flow
- Stubbed email service (logs only; ready to swap for Resend/Postmark later)
- All existing tables refactored from `coach_id` to `organization_id`
- All RLS policies rewritten to use organization membership

**Phase 1 size estimate:** Substantial. Touches every existing table and
every RLS policy. Probably 3-5 Claude Code sessions.

---

## Phase 2: Squads, COPPA Alignment, Raffle History

**Goal:** Add the squad model and tighten data handling for COPPA. After
Phase 2 the app has multiple squads per organization, structured player
names, anonymizing deletion, and database-backed raffle history.

**Adds:**
- `squads` table (sub-teams under each organization)
- Structured grade/age grouping per squad (with coach-level default)
- `roster.first_name` + `roster.last_initial` + `roster.nickname`
- `roster.roster_status` enum (`member` / `visitor`)
- `roster.squad_id` (nullable; null means visitor)
- `events.squad_ids` (array of participating squads)
- `events.player_ids` (array of player UUIDs replacing the name strings)
- `raffle_winners` table with CASCADE deletion
- `purge_player()` stored procedure for anonymizing deletion
- Squad management UI (create, edit, archive)
- Quick Start attendance flow with multi-squad selector
- Org-wide leaderboard with squad filter
- Coach picks raffle scope per spin
- localStorage cleanup logic

**Phase 2 size estimate:** Moderate. Builds on a stable Phase 1 foundation.
Probably 2-3 Claude Code sessions.

---

## Critical Pre-Implementation Reminders

Before starting Phase 1, verify these things or budget time to handle them:

1. **Back up your Supabase database.** Even though existing data is test
   data, a backup costs nothing and protects against surprises.
2. **Check HTTPS enforcement** on your hosting provider (force-HTTPS toggle
   on Vercel/Netlify/etc.).
3. **Note your Supabase project URL and service role key** — Claude Code may
   need them for the migration.
4. **Confirm you can run migrations locally** before pushing to production.
   The migrations should be tested against a local Supabase instance first.
5. **Have a way to test invite links.** You'll need at least two email
   addresses (or two browsers / incognito sessions) to test the org owner →
   assistant coach flow.

---

## Things Explicitly Deferred (Not in This Brief)

These came up during brainstorming and were intentionally pushed to later:

- **Parent email + Verifiable Parental Consent workflows.** Out of scope
  while the app stays within COPPA's internal-operations exemption. Revisit
  when adding parent-facing features.
- **Real email delivery.** Phase 1 uses a stubbed email provider that logs
  invitations instead of sending them. Add Resend/Postmark when ready.
- **Multi-organization users.** A coach helping two clubs would need
  separate accounts in v1. The data model supports multi-org membership;
  the UI doesn't expose it yet.
- **Multi-team players.** A player who legitimately practices with two
  squads is handled via the guest mechanism in v1. Promote to a join table
  if usage shows it's needed.
- **Season grade-advance feature.** "Bump all grade-based squads by one
  level for the new season" — structured grade fields make this possible
  but it's not built.
- **Parent / player roles and portals.** Out of scope for v1.
- **Hard delete of player UUIDs from archived event JSONB.** The
  anonymization in `purge_player()` is sufficient for COPPA. True erasure
  from archived JSON snapshots is more work and can be added if GDPR-style
  requirements become relevant.
- **Column-level encryption.** Not justified by the threat model given how
  little PII is stored. Disk-level encryption (Supabase default) is
  sufficient.

---

## Open Questions for Future You

If you come back to this and feel uncertain, these are the topics most
likely to need a second look:

- Is "Squad" still the right user-facing word, or has usage suggested
  something else?
- Are coaches actually using the guest mechanism for play-ups, or are they
  asking for true multi-squad membership?
- Has the org-wide-leaderboard-with-filter model held up, or do users
  prefer per-squad as the default?
- Is the assistant-coach role too restrictive (e.g., they want to add
  guests but can't add players)?

---

## Contact / Context

This brief was developed through an extended brainstorming session. If
specific decisions seem strange when you return to them, the rationale is
captured in `DECISIONS.md` — read that before second-guessing any choice.

**Last updated:** When this package was generated.
