# Handing This Off to Claude Code

A practical guide for using these briefs with Claude Code when you're
ready to implement.

---

## Before You Start

1. **Have a backup of your Supabase database.** Even though Phase 2
   intentionally wipes test data, you want a rollback option for the
   Phase 1 RLS refactor.
2. **Make sure you can run migrations locally** against a local Supabase
   instance before pushing to production. The Supabase CLI supports
   local dev.
3. **Have two email addresses available** for testing the invite flow.
   A second browser, incognito window, or a second device works too.
4. **Open the repo in your IDE.** Have VS Code or your editor of choice
   open on the repo, with Claude Code running in a terminal tab inside
   it. You'll want to watch diffs land in real time.

---

## How to Phase the Work

### Phase 1 Session Plan

Phase 1 is large. Don't try to do it in one session. Break it like this:

**Session 1A: Schema and migrations**
- Goal: `migrations/011_organizations.sql` written and reviewed
- Don't apply the migration yet — just get it written and read it
  carefully
- Verify the table definitions, the backfill logic, and the RLS
  policies match what you want

**Session 1B: Apply the migration locally and verify**
- Run the migration against a local Supabase
- Verify: backfilled orgs exist, memberships exist, RLS helpers work
- Try a few hand-crafted queries to confirm RLS scoping works as
  expected
- If something is wrong, fix it now before generating code

**Session 1C: Edge Functions**
- `create-invitation` and `accept-invitation` Edge Functions
- The email stub provider
- Test invitation creation end-to-end (token generation, expiry, etc.)

**Session 1D: Frontend — onboarding and invitation acceptance**
- The post-signup "start new org / join existing" flow
- The `/accept-invite?token=...` landing page
- Verify a full invite cycle works manually

**Session 1E: Frontend — Settings → Members**
- The members management page
- The ownership transfer flow
- Member role editing

**Session 1F: Refactor everything else**
- All existing screens to use `organization_id` from context
- All RPC calls to pass `organization_id`
- The Org Switcher in the app header
- Update of remaining hardcoded coach-name references

**Session 1G: Verification pass**
- Walk the Phase 1 Acceptance Criteria list
- Apply to production once verified locally

### Phase 2 Session Plan

Phase 2 is smaller. Two or three sessions:

**Session 2A: Migration**
- `migrations/012_squads_coppa_raffle.sql` written and applied locally
- The wipe is destructive — confirm test data only before running
- Verify CHECK constraints work as intended

**Session 2B: Backend updates + Squad management UI**
- Updated atomic RPCs
- `purge_player` function
- Squad management page
- Create/edit squad form
- Settings → General radio for default grouping

**Session 2C: Attendance flow + Reports + Raffle + Roster updates**
- Quick Start squad selector
- New attendance screen with expected/guest sections
- Add/edit player form with structured fields
- Leaderboard filter
- Reports filter and CSV export
- Raffle scope picker and DB-backed winner history
- localStorage cleanup

**Session 2D: Verification + Privacy policy**
- Walk the Phase 2 Acceptance Criteria list
- Update PRIVACY.md
- Apply to production

---

## What to Tell Claude Code at the Start

When you start a Claude Code session, paste a prompt like this:

> I'm implementing a multi-phase refactor of the Kaizen Tracker app.
> The full brief is in `BRIEF/README.md`, `BRIEF/DECISIONS.md`,
> `BRIEF/PHASE1-ORGANIZATIONS-BRIEF.md`, and
> `BRIEF/PHASE2-SQUADS-COPPA-BRIEF.md`.
>
> Read all four files first. Then ask me which session we're working on.

(Replace `BRIEF/` with wherever you put this package in the repo.)

Then for a specific session, prompt with the session number from the
plan above, e.g.:

> Let's do Session 1A: write `migrations/011_organizations.sql`. Read
> the existing migrations 001-010 first to understand the patterns
> and conventions. Then write 011 following the spec in PHASE 1.

---

## What to Watch For

**Claude Code may improvise on details not in the brief.** If you see
choices being made that aren't in the brief, decide if you care:
either correct them, or accept and document them.

**The migration 011 backfill is the highest-risk single step.** It
creates one org per existing coach and rewires every existing row.
Review it carefully before applying. Run it against a copy of prod
first if you have any real data.

**RLS bugs are silent.** A wrong RLS policy doesn't throw an error —
it just allows or denies access incorrectly. Test cross-org isolation
specifically: sign in as user from Org A, try to read Org B's data,
confirm it's denied. Use the Supabase SQL editor to spot-check.

**The `coach_id` → `organization_id` rename touches many files.** After
Claude Code finishes, run `grep -r coach_id src/` (or equivalent in
your IDE). If anything remains, it's likely a bug.

**Claude Code's autonomy is real but bounded.** It will pause when
something is genuinely ambiguous. If it asks a clarifying question,
answer based on the brief, and if the brief doesn't cover it, make
a defensible call and document the choice in DECISIONS.md.

---

## Cost & Time Expectations

This is a substantial refactor. Realistic estimates:

- **Phase 1:** 4-8 hours of Claude Code session time, plus
  verification time
- **Phase 2:** 3-5 hours of Claude Code session time, plus
  verification time
- **Calendar time:** 2-4 weeks per phase if you're doing this
  part-time. Don't rush — between sessions, use the app and let
  issues surface.

---

## After Each Session

A few habits worth keeping:

1. **Commit frequently.** Don't let a session's worth of changes
   sit uncommitted. `git add -p` is your friend for reviewing
   what's actually changed.
2. **Run the app locally after every session.** Don't just trust
   that things compile.
3. **Update the brief if decisions change.** If you discover
   mid-implementation that some choice was wrong, edit
   DECISIONS.md to reflect the new state. This is your future
   memory.
4. **Take notes on weirdness.** If something Claude Code did
   confused you, write it down. You'll see the pattern again.

---

## When You're Done

After Phase 2 verification:

1. **Archive this brief package** somewhere in the repo (e.g.,
   `docs/historical-briefs/multitenancy/`)
2. **Tag the release** in git: `v2.0-multitenant` or similar
3. **Update the main README** to reflect the new architecture
4. **Take a break.** This is real work.

---

## If You Get Stuck

A few escape hatches:

- **Re-read DECISIONS.md.** Most "why did I do it this way?"
  questions are answered there.
- **Ask Claude Code to explain its plan before executing.** If
  you're uncertain about an upcoming session, tell it to outline
  what it'll do without writing code, then review the outline.
- **Roll back to a known-good commit.** Git is your friend. If a
  session goes sideways, `git reset --hard` to before the session
  and try again with a different prompt.
- **Phase 1 can run for weeks before Phase 2.** There's no rush.
  Live with Phase 1 first.
