# Phase 1: Multi-Tenancy Foundation

> Transform the Kaizen Tracker from a single-coach app into a multi-coach,
> multi-organization app. After Phase 1, the app does everything it did
> before — but data is scoped by organization, and a head coach can invite
> assistant coaches.

---

## Goal

Stand up the multi-tenant data model and invitation system without
introducing any new user-facing features. The app's existing
functionality (roster, events, leaderboard, raffle, reports) should
continue to work exactly as before, but now scoped by `organization_id`
instead of `coach_id`.

**Success criterion:** A new user can sign up, choose "Start a new
organization," and have a working app identical to today's experience.
They can then invite an assistant coach, who accepts the invitation and
sees the same organization's data.

---

## Schema Changes

A single new migration file: `migrations/011_organizations.sql`.

### New Tables

```sql
-- ============================================================
-- 011_organizations.sql
-- Multi-tenancy foundation: organizations, members, invitations.
-- Refactors all existing tables from coach_id to organization_id.
-- ============================================================

-- The organization itself
CREATE TABLE IF NOT EXISTS public.organizations (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name            TEXT NOT NULL CHECK (char_length(name) BETWEEN 1 AND 60),
  logo_url        TEXT,
  primary_color   TEXT,
  owner_user_id   UUID NOT NULL REFERENCES auth.users(id),
  squad_grouping_default TEXT NOT NULL DEFAULT 'grade'
    CHECK (squad_grouping_default IN ('grade', 'age', 'mixed')),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS organizations_owner_user_id_idx
  ON public.organizations(owner_user_id);

-- Membership: who belongs to which org, in what role
CREATE TABLE IF NOT EXISTS public.organization_members (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  user_id         UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role            TEXT NOT NULL CHECK (role IN ('owner', 'head_coach', 'assistant_coach')),
  display_name    TEXT,           -- optional, defaults to auth.users email prefix
  joined_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT unique_membership UNIQUE (organization_id, user_id)
);

CREATE INDEX IF NOT EXISTS organization_members_user_id_idx
  ON public.organization_members(user_id);
CREATE INDEX IF NOT EXISTS organization_members_org_id_idx
  ON public.organization_members(organization_id);

-- Only one owner per organization
CREATE UNIQUE INDEX IF NOT EXISTS one_owner_per_org
  ON public.organization_members(organization_id)
  WHERE role = 'owner';

-- Pending invitations
CREATE TABLE IF NOT EXISTS public.organization_invitations (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  email           TEXT NOT NULL CHECK (char_length(email) BETWEEN 3 AND 320),
  role            TEXT NOT NULL CHECK (role IN ('head_coach', 'assistant_coach')),
  token           TEXT NOT NULL UNIQUE,        -- random 32-byte hex
  invited_by      UUID NOT NULL REFERENCES auth.users(id),
  invited_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at      TIMESTAMPTZ NOT NULL DEFAULT (now() + interval '7 days'),
  accepted_at     TIMESTAMPTZ,
  accepted_by     UUID REFERENCES auth.users(id),
  revoked_at      TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS organization_invitations_token_idx
  ON public.organization_invitations(token)
  WHERE accepted_at IS NULL AND revoked_at IS NULL;
CREATE INDEX IF NOT EXISTS organization_invitations_org_id_idx
  ON public.organization_invitations(organization_id);

-- Pending ownership transfers
CREATE TABLE IF NOT EXISTS public.ownership_transfers (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  initiated_by    UUID NOT NULL REFERENCES auth.users(id),
  recipient       UUID NOT NULL REFERENCES auth.users(id),
  initiated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at      TIMESTAMPTZ NOT NULL DEFAULT (now() + interval '7 days'),
  accepted_at     TIMESTAMPTZ,
  rejected_at     TIMESTAMPTZ,
  CONSTRAINT no_self_transfer CHECK (initiated_by <> recipient)
);
```

### Refactoring Existing Tables

Every existing table that has `coach_id` gets an `organization_id` column.
For data preservation during the refactor, the migration:

1. Adds the new `organization_id` column (nullable initially)
2. Creates one organization per distinct `coach_id` in the system
3. Backfills `organization_id` on every row
4. Drops the old `coach_id` column
5. Makes `organization_id` NOT NULL
6. Recreates RLS policies against the new column

```sql
-- ============================================================
-- Backfill: create one org per existing coach
-- ============================================================

-- For each existing coach (user with data), create an organization
-- owned by them. The org's name defaults to their team_settings.team_name
-- if it exists, otherwise "My Organization".
INSERT INTO public.organizations (id, name, owner_user_id, logo_url, primary_color)
SELECT
  gen_random_uuid(),
  COALESCE(ts.team_name, 'My Organization'),
  ts.coach_id,
  ts.logo_url,
  ts.primary_color
FROM public.team_settings ts
ON CONFLICT DO NOTHING;

-- Create owner memberships
INSERT INTO public.organization_members (organization_id, user_id, role, display_name)
SELECT o.id, o.owner_user_id, 'owner', ts.coach_name
FROM public.organizations o
JOIN public.team_settings ts ON ts.coach_id = o.owner_user_id
ON CONFLICT DO NOTHING;

-- ============================================================
-- Add organization_id to every table that has coach_id.
-- Pattern repeated for: roster, events, active_session,
-- archived_event_sets, activity_log, team_settings, purge_lifecycle,
-- consent_storage, and any others.
-- ============================================================

-- Example for `roster` (repeat for every coach_id-bearing table):
ALTER TABLE public.roster
  ADD COLUMN IF NOT EXISTS organization_id UUID REFERENCES public.organizations(id) ON DELETE CASCADE;

UPDATE public.roster r
SET organization_id = o.id
FROM public.organizations o
WHERE o.owner_user_id = r.coach_id AND r.organization_id IS NULL;

ALTER TABLE public.roster
  ALTER COLUMN organization_id SET NOT NULL,
  DROP COLUMN coach_id;

CREATE INDEX IF NOT EXISTS roster_organization_id_idx
  ON public.roster(organization_id);
```

**IMPORTANT for Claude Code:** repeat this exact pattern for every table
that has `coach_id`. Inventory those tables by grepping migrations
001-010 for `coach_id` references. The full list includes (at minimum):
`roster`, `events`, `active_session`, `archived_event_sets`,
`activity_log`, `team_settings`, `purge_lifecycle`, `consent_storage`.

### RLS Policy Rewrites

Every existing RLS policy needs to change from
`auth.uid() = coach_id`
to
`organization_id IN (SELECT organization_id FROM organization_members WHERE user_id = auth.uid())`.

A reusable helper function makes this cleaner:

```sql
-- Helper: returns true if the current user is a member of the given org
CREATE OR REPLACE FUNCTION public.is_org_member(org_id UUID)
RETURNS BOOLEAN
LANGUAGE SQL
SECURITY DEFINER
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.organization_members
    WHERE organization_id = org_id AND user_id = auth.uid()
  );
$$;

-- Helper: returns the current user's role in the given org, or NULL
CREATE OR REPLACE FUNCTION public.org_role(org_id UUID)
RETURNS TEXT
LANGUAGE SQL
SECURITY DEFINER
STABLE
AS $$
  SELECT role FROM public.organization_members
  WHERE organization_id = org_id AND user_id = auth.uid()
  LIMIT 1;
$$;

-- Helper: returns true if user can manage org (owner or head_coach)
CREATE OR REPLACE FUNCTION public.can_manage_org(org_id UUID)
RETURNS BOOLEAN
LANGUAGE SQL
SECURITY DEFINER
STABLE
AS $$
  SELECT public.org_role(org_id) IN ('owner', 'head_coach');
$$;
```

**Example RLS policies for the new tables:**

```sql
ALTER TABLE public.organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.organization_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.organization_invitations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ownership_transfers ENABLE ROW LEVEL SECURITY;

-- Anyone in the org can read it
CREATE POLICY "members_can_read_org" ON public.organizations
  FOR SELECT USING (public.is_org_member(id));

-- Only owners and head coaches can update org settings
CREATE POLICY "managers_can_update_org" ON public.organizations
  FOR UPDATE USING (public.can_manage_org(id));

-- Only owner can delete the org
CREATE POLICY "owner_can_delete_org" ON public.organizations
  FOR DELETE USING (public.org_role(id) = 'owner');

-- Members can see the membership list of their orgs
CREATE POLICY "members_can_read_members" ON public.organization_members
  FOR SELECT USING (public.is_org_member(organization_id));

-- Owners and head coaches can manage memberships (except owner can't be deleted)
CREATE POLICY "managers_can_insert_members" ON public.organization_members
  FOR INSERT WITH CHECK (public.can_manage_org(organization_id));

CREATE POLICY "managers_can_delete_members" ON public.organization_members
  FOR DELETE USING (
    public.can_manage_org(organization_id)
    AND role <> 'owner'  -- never delete an owner; use transfer flow
  );

-- Only managers can see/create invitations
CREATE POLICY "managers_can_read_invitations" ON public.organization_invitations
  FOR SELECT USING (public.can_manage_org(organization_id));

CREATE POLICY "managers_can_create_invitations" ON public.organization_invitations
  FOR INSERT WITH CHECK (public.can_manage_org(organization_id));

CREATE POLICY "managers_can_revoke_invitations" ON public.organization_invitations
  FOR UPDATE USING (public.can_manage_org(organization_id));
```

**Example refactored RLS for existing tables (pattern for `roster`):**

```sql
-- Drop old coach-based policies
DROP POLICY IF EXISTS "coach_can_read_roster" ON public.roster;
DROP POLICY IF EXISTS "coach_can_modify_roster" ON public.roster;

-- New org-based policies
CREATE POLICY "members_can_read_roster" ON public.roster
  FOR SELECT USING (public.is_org_member(organization_id));

CREATE POLICY "managers_can_insert_roster" ON public.roster
  FOR INSERT WITH CHECK (public.can_manage_org(organization_id));

CREATE POLICY "managers_can_update_roster" ON public.roster
  FOR UPDATE USING (public.can_manage_org(organization_id));

CREATE POLICY "managers_can_delete_roster" ON public.roster
  FOR DELETE USING (public.can_manage_org(organization_id));
```

For tables that assistants should be able to write to (events,
active_session), use `is_org_member` instead of `can_manage_org` for
INSERT/UPDATE:

```sql
CREATE POLICY "members_can_insert_events" ON public.events
  FOR INSERT WITH CHECK (public.is_org_member(organization_id));
```

### Atomic Operations Update

The stored procedures in `migrations/003_atomic_operations.sql` (e.g.,
`save_session`) currently take `coach_id` or rely on `auth.uid()`. They
need updating to accept `organization_id` and verify membership.

```sql
-- Example: updated save_session signature
CREATE OR REPLACE FUNCTION public.save_session(
  p_organization_id UUID,
  p_event_data JSONB,
  -- ... other params
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_event_id UUID;
BEGIN
  -- Verify caller is a member of the organization
  IF NOT public.is_org_member(p_organization_id) THEN
    RAISE EXCEPTION 'Not authorized for organization %', p_organization_id;
  END IF;

  -- ... rest of original logic, using p_organization_id where coach_id was
END;
$$;
```

**Audit:** every RPC in 003 needs review. The full list of RPCs is in
migration 003 — go through each one.

### Admin View Update

Migration 005's `admin_coach_summary_view` becomes
`admin_organization_summary_view`, aggregating per-organization rather
than per-coach. Columns to surface:

- Organization name
- Owner display name + email
- Member count (broken down by role)
- Squad count (always 0 in Phase 1; Phase 2 populates this)
- Roster count
- Event count
- Last activity timestamp

---

## Edge Functions

Create a Supabase Edge Function `create-invitation` that:

1. Verifies the caller is a manager (`can_manage_org`) of the target org
2. Generates a cryptographically random 32-byte hex token
3. Inserts the invitation row
4. **Calls the email service stub** (`emailProvider.sendInvitation(...)`)
5. Returns the invitation row including the token to the caller

This is server-side so the future real-email API key never touches
the client.

The email service stub:

```typescript
// src/lib/email/provider.ts
export interface EmailProvider {
  sendInvitation(args: {
    toEmail: string;
    organizationName: string;
    inviterName: string;
    role: 'head_coach' | 'assistant_coach';
    inviteUrl: string;
    expiresAt: Date;
  }): Promise<{ sent: boolean; messageId?: string }>;
}

// src/lib/email/noop-provider.ts
export const noopEmailProvider: EmailProvider = {
  async sendInvitation(args) {
    console.log('[NoOpEmail] Would have sent invitation:', {
      to: args.toEmail,
      org: args.organizationName,
      inviter: args.inviterName,
      role: args.role,
      url: args.inviteUrl,
      expires: args.expiresAt.toISOString(),
    });
    return { sent: false };
  },
};

// src/lib/email/index.ts
import { noopEmailProvider } from './noop-provider';
export const emailProvider = noopEmailProvider;
// When ready, swap this line for: export { resendProvider as emailProvider } from './resend-provider';
```

Create a similar Edge Function `accept-invitation` that:

1. Takes a token from the URL
2. Looks up the invitation row
3. Verifies: not expired, not already accepted, not revoked
4. Verifies the caller's `auth.user().email` matches `invitation.email`
   (case-insensitive comparison)
5. Creates the `organization_members` row in a transaction with marking
   the invitation as accepted
6. Returns the organization the user just joined

---

## Frontend Changes

### Authentication / Onboarding Flow

After signup, the existing flow goes straight into the dashboard. That
needs an intermediate step:

```
[Signed up successfully]
       ↓
[Check: does this user have any organization memberships?]
       ↓
   No memberships?
       ↓
[Onboarding screen: "Welcome! What brings you here?"]
       ↓                              ↓
[Start a new organization]    [Join with an invite link]
       ↓                              ↓
[New org form]            [Paste invite link or token]
       ↓                              ↓
[Land on dashboard]       [Accept → land on dashboard]
```

**Crucially, both options should be visually equal weight on the
onboarding screen.** Don't make "Start a new organization" the obvious
default — many users will be assistants expecting an invite.

Recommended copy:

> **Welcome to Kaizen Tracker**
>
> [Card] **Join an existing organization**
> If your head coach or program director sent you an invite link, click
> below to accept it.
> [Button: I have an invite link]
>
> [Card] **Start a new organization**
> Setting up your own program? Create a new organization for your team.
> [Button: Create organization]

### "Start a new organization" form

- Organization name (required, with soft uniqueness warning: query
  existing orgs; if a match exists, show "An organization named X
  already exists. Continue anyway?")
- Logo upload (optional)
- Primary color (optional)
- Coach display name (defaults to email prefix)

On submit: create org, create owner membership, redirect to dashboard.

### Invite acceptance flow

URL pattern: `/accept-invite?token=<token>`

- If not signed in: redirect to sign-in/sign-up, preserving token in
  query string or sessionStorage
- After authenticated: call `accept-invitation` Edge Function
- On success: redirect to dashboard, show toast "Welcome to {org name}!"
- On failure (expired, wrong email, etc.): show clear error with next
  steps

### Organization Switcher

Most users will only have one org, but the data model allows multiple.
Add a minimal switcher in the app header that:

- Shows current org name + role badge
- If user has 2+ memberships: dropdown lets them switch
- If user has 1 membership: just displays it (no dropdown)

Persist the current org selection in localStorage as
`current_organization_id`. On app load, verify the user is still a
member of that org; if not, fall back to their first membership.

### Settings → Members page

A new tab in Settings (or a new Settings page) for organization
membership management. Only visible to owners and head coaches.

Sections:

1. **Pending invitations** — list of unaccepted invitations with:
   - Email, role, invited date, expires date, invited by
   - "Copy link" button (copies `https://yourapp.com/accept-invite?token=...`)
   - "Revoke" button
2. **Active members** — list of members with:
   - Display name, email, role, joined date
   - For owners: ability to change another member's role (head_coach ↔
     assistant_coach)
   - For owners: ability to remove members (other than themselves)
   - For owners: "Transfer ownership" button (per head_coach member)
3. **Invite a new member** — form with email + role selector + submit

### Ownership Transfer UI

In Settings → Members, owner sees "Transfer ownership" next to each
Head Coach. Clicking it:

1. Confirmation modal: "Transfer ownership of {org} to {member}? They
   will need to accept. You will become a Head Coach."
2. On confirm, create an `ownership_transfers` row
3. Show "Pending transfer" indicator until accepted/rejected

The recipient sees a banner at the top of their app: "{Owner name} has
offered you ownership of {org}. [Accept] [Decline]"

On accept (atomically):
- Set initiator's role to `head_coach`
- Set recipient's role to `owner`
- Update `organizations.owner_user_id` to recipient
- Mark transfer row as accepted

### Header / App Shell Changes

The existing app header probably shows "Kaizen Warriors" hardcoded or
pulled from `team_settings`. Update it to show the current org's name
from the `organizations` table.

Coach name display (visible in welcome message, etc.) comes from the
current user's `organization_members.display_name`, with email prefix
as fallback.

---

## TypeScript Type Updates

Wherever `coach_id` appeared in types, it becomes `organization_id`.

New types to add:

```typescript
// src/types/organization.ts

export type OrgRole = 'owner' | 'head_coach' | 'assistant_coach';

export interface Organization {
  id: string;
  name: string;
  logo_url: string | null;
  primary_color: string | null;
  owner_user_id: string;
  squad_grouping_default: 'grade' | 'age' | 'mixed';
  created_at: string;
  updated_at: string;
}

export interface OrganizationMember {
  id: string;
  organization_id: string;
  user_id: string;
  role: OrgRole;
  display_name: string | null;
  joined_at: string;
}

export interface OrganizationInvitation {
  id: string;
  organization_id: string;
  email: string;
  role: 'head_coach' | 'assistant_coach';
  token: string;
  invited_by: string;
  invited_at: string;
  expires_at: string;
  accepted_at: string | null;
  accepted_by: string | null;
  revoked_at: string | null;
}

export interface OwnershipTransfer {
  id: string;
  organization_id: string;
  initiated_by: string;
  recipient: string;
  initiated_at: string;
  expires_at: string;
  accepted_at: string | null;
  rejected_at: string | null;
}
```

Audit every existing type that references `coach_id` and rename the
field. Be aware that some types may need both (during the transitional
build) — the migration drops `coach_id` from the DB so types should
only reference `organization_id` by the time Phase 1 ships.

---

## File-by-File Task List

When handing this to Claude Code, work in roughly this order:

1. **`migrations/011_organizations.sql`** — the full migration
2. **`migrations/README.md`** — add 011 to the migration log
3. **`src/types/organization.ts`** — new types
4. **`src/types/*.ts`** — update existing types (rename `coach_id` →
   `organization_id`)
5. **`src/lib/email/provider.ts`** + **`src/lib/email/noop-provider.ts`**
   + **`src/lib/email/index.ts`** — email service abstraction
6. **`supabase/functions/create-invitation/index.ts`** — Edge Function
7. **`supabase/functions/accept-invitation/index.ts`** — Edge Function
8. **`src/lib/organization.ts`** — client helpers: get current org,
   list memberships, switch org
9. **`src/contexts/OrganizationContext.tsx`** — React context for
   current org (if using context pattern; otherwise adapt)
10. **`src/app/onboarding/`** — new onboarding flow components
11. **`src/app/accept-invite/`** — invite acceptance landing page
12. **`src/app/settings/members.tsx`** — members management page
13. **`src/app/settings/transfer-ownership.tsx`** — transfer flow
14. **All existing screens** — update to read `organization_id` from
    context instead of relying on `auth.uid()` as the implicit scope
15. **Verify all RPC calls** — pass `organization_id` to the updated
    procedures

---

## Acceptance Criteria

Before considering Phase 1 done, verify:

- [ ] A new user can sign up and create an organization
- [ ] An existing single-coach user from before the migration has been
      migrated to an owner of a backfilled organization
- [ ] All previous functionality works exactly as before (roster,
      events, leaderboard, raffle, reports)
- [ ] An owner can invite a head coach; the invitation shows up in
      Members with a copyable link
- [ ] The invite link, when opened by the correct email, allows them
      to join the org as a head coach
- [ ] The invite link, when opened by a different email, fails with a
      clear error
- [ ] An expired or revoked invite link fails with a clear error
- [ ] An assistant coach has read access to roster but cannot
      add/remove players (RLS enforces this; UI hides buttons)
- [ ] An assistant coach can take attendance and run the raffle
- [ ] Ownership transfer works: owner initiates, recipient sees a
      banner, on accept the roles swap atomically
- [ ] RLS prevents cross-org data leaks: a member of Org A cannot
      query Org B's data even via direct Supabase calls
- [ ] The admin organization summary view shows per-org aggregates
- [ ] HSTS header is sent in production
- [ ] The activity log records member adds, removals, role changes,
      and ownership transfers
- [ ] The stubbed email provider logs invitations to the console (so
      developers can see what would have been sent)

---

## Notes & Caveats for Claude Code

- **The backfill creates one org per existing coach.** If a coach
  doesn't have a `team_settings` row, generate one with default values
  before creating the org. Don't drop coaches just because they have
  no team_settings.
- **`coach_id` should not appear anywhere in the codebase after Phase
  1.** Grep for it as a final check before declaring complete.
- **Don't try to support both `coach_id` and `organization_id`
  simultaneously.** It's a hard cutover. Keep the migration atomic
  (use a transaction wrapper if not already implicit).
- **Some screens may have hardcoded "Kaizen Warriors" or coach-name
  text.** These need to be reactive to the current organization
  context.
- **The current PWA may cache the old single-coach data model in
  IndexedDB or localStorage.** Bump any cache versions during Phase 1
  so users get a fresh slate on next load.
- **Test with two browsers/incognito sessions.** You'll need to verify
  the invite flow from one user to another.
- **Document the email stub clearly.** Add a comment at the top of
  `noop-provider.ts` explaining: "When ready to send real emails,
  swap this in `src/lib/email/index.ts` for a Resend or Postmark
  implementation. The API contract is defined by `EmailProvider`."
