# Decisions Locked In

Every meaningful choice made during the brainstorm, with the rationale.
Read this before second-guessing any decision in the phase briefs.

---

## Vocabulary

| Concept | Chosen Name | Why |
|---|---|---|
| The org-level container | **Organization** (or "Org") | Standard SaaS terminology; matches the data model |
| The sub-team within an org | **Squad** | Common in youth basketball, doesn't conflict with "Team" or "Roster", reads naturally in UI ("Add to Squad", "Switch Squad") |
| The org's main display name | The user names the org freely | E.g., "Kaizen Warriors" |
| Squad display label | Formatted via central helper | "7th Grade Blue", "12U Elite", "Elite" for mixed |

---

## Roles & Permissions

**Three roles, flat structure:**

- **Owner** (one per org): Created the org or had ownership transferred to them. Full control including billing, ownership transfer, and org deletion. Owner is implicitly a Head Coach for permission purposes.
- **Head Coach** (multiple allowed): Manages squads, roster, events, invitations. Cannot transfer ownership or delete the org.
- **Assistant Coach** (multiple allowed): Takes attendance, runs the raffle, views stats. Cannot create/delete squads, cannot manage roster (add/remove players), cannot invite other coaches.

**Owner+HeadCoach is one role assignment**, not two. Owner is a superset of Head Coach (GitHub/Slack/Notion pattern).

**Rationale:** Three roles is the sweet spot across youth sports apps for usability without losing organizational hierarchy. Skipping a Parent role because parent-facing features are a v3+ direction.

---

## Multi-Tenancy Architecture

**Approach: Organizations as first-class entities (Approach A from brainstorm).**

Every existing `coach_id` column becomes `organization_id`. RLS policies use `auth.uid() IN (SELECT user_id FROM organization_members WHERE organization_id = ...)`.

**Rationale:** Doing it now while data is wipeable is much cheaper than later. Provides a clean foundation for assistant coaches, future multi-org users, and role expansion.

**Membership is flat:** `organization_members(user_id, organization_id, role)`. No nested hierarchy. If a "Director of Coaching" role ever becomes meaningful, it's just a new value in the role enum.

---

## Invitations

- **Invite delivery:** Manual link sharing in v1. Head coach generates an invite, copies the link, sends it however (email/text/in-person). Email service is stubbed — logs only — and can be swapped to Resend/Postmark later without restructuring.
- **Invite link security:** Strict. The link only works for the email address it was sent to. After signup/login, system verifies `auth.user().email === invitation.email`. Mismatched email → error with explanation.
- **Invite expiry:** 7 days.
- **Token storage:** Random 32-byte token, stored as text in the `organization_invitations` table.
- **Sent server-side:** Invitation creation happens through a Supabase Edge Function (even in v1 with stubbed email) so the API key for real email later doesn't leak to the client.

**Org name uniqueness:** Not enforced at the database level. Two real basketball programs could legitimately share a name. UI shows a soft warning if the chosen name matches an existing org ("An organization named X already exists. Are you sure you want to create a separate one?").

**Ownership transfer:** Owner initiates → recipient (must be an existing Head Coach in the org) gets an in-app prompt to accept → on accept, roles swap atomically. The recipient must explicitly accept.

---

## Squads

**One squad per player.** A player's `squad_id` is a single foreign key (nullable). The "plays up occasionally" case is handled via the existing guest mechanism: when a 6th grader attends a 7th grade practice, they show up as a guest *for that event*. No multi-squad membership in v1.

**Rationale:** Simpler data model; matches Pattern A (age cohort) which the original sub-team names ("7th Grade Blue", "5th Grade Gray") suggest. If real usage shows frequent multi-squad attendance, migrate to a join table later.

**Squad grouping:** Three modes, structured.

- `grade` mode: `grade_min` and `grade_max` (0=K through 12). Single-grade squads have `grade_min == grade_max`. Range supported for dual-grade squads ("5th–6th Blue").
- `age` mode: `age_max` (integer). Displayed as "12U" for `age_max = 12`.
- `mixed` mode: no grade or age data.

**Coach default + per-squad override:** `team_settings.squad_grouping_default` stores the coach-level default (set in Settings). The Create Squad form pre-selects it. The coach can override per squad.

**Squad name:** Free text, separate field from grouping. "Blue Team", "Elite", "Developing" — whatever the org calls it. Combined with grouping by the display formatter ("7th Grade Blue", "12U Elite").

**Squad colors:** Small palette of preset swatches + "Custom" hex option. Free hex string stored in DB.

**Squad sort order in dropdowns:** Ascending by grade/age, then by `sort_order` field (manual drag-to-reorder for same-grade), then alphabetical by name. Mixed squads sort to the bottom.

**Squad deletion:** Soft archive by default + a separate "move players first" prompt if any players are still assigned. Never hard-delete (preserves historical event associations).

---

## Events

**Multi-squad events:** `events.squad_ids` is a JSONB array of squad UUIDs participating in the event. Allows single-squad practices, combined-squad practices, and all-squads training (the array contains every active squad UUID at the time of the event).

**Rationale:** Mirrors the JSONB pattern of `player_ids`. Reports like "all 7th Blue events" use `squad_ids @> '[blue-uuid]'::jsonb` which works cleanly.

**Player references by UUID:** `events.player_ids` is a JSONB array of `roster.id` UUIDs. The old `events.players` (name strings) column is dropped in Phase 2 because existing data is being wiped.

**Active session:** Gets a `squad_ids` array too, since the in-progress session is for a specific squad selection.

---

## Quick Start Attendance Flow

1. Coach hits Quick Start.
2. **Always show squad multi-selector**, even if there's only one squad. Starts empty — coach picks every time. (No defaults to last-used or to-all.)
3. After selection, attendance screen shows:
   - **Expected players** (members of the selected squads). If 2+ squads selected, grouped by squad with collapsible headers. If just one squad, flat list (no header).
   - **Guest search field** at the bottom labeled "Add a guest...". Searches the *entire roster* (across all squads) as the coach types, with squad badges. If no match, offers "+ Add new player" with two options: "Add as one-time visitor" or "Add and assign to a squad".

**Rationale:** The cross-squad search makes guesting from another squad as easy as guesting from outside the system. The "expected vs guest" status is computed per-event from membership, not stored on the player.

---

## Player Identity & COPPA Alignment

**Structured name fields:**

- `first_name` (required, 1–30 chars)
- `last_initial` (required, single uppercase letter, enforced by CHECK constraint)
- `nickname` (optional, 1–20 chars, displayed when present)

Display formatter rules:
- Default: `"{first_name} {last_initial}."` → "Marcus J."
- With nickname: `"{nickname}"` → "Tall Marcus" or "Jake"
- Coach name (`organizations.owner_display_name` or similar): unrestricted, since coaches are adults

**Rationale:** Database-level enforcement of "first + initial" satisfies COPPA's data minimization principle. Nickname handles duplicates and preferred names without re-introducing full-name storage as a default.

**Roster status:** New `roster_status` enum: `'member'` (assigned to a squad) or `'visitor'` (no squad, possibly one-time). The old `is_guest` boolean is dropped.

**Player deletion = anonymization:** A stored procedure `purge_player(player_id)` that:
- Sets `first_name = 'Deleted'`, `last_initial = 'X'`, `nickname = NULL`
- Sets `roster_status = 'archived'` (a third enum value)
- Sets `squad_id = NULL`
- Deletes related `raffle_winners` rows (CASCADE)
- Records an entry in `activity_log` with no PII (just the action + timestamp)

**Rationale:** Preserves stat integrity (UUIDs stay valid in event arrays and archived snapshots) while removing all PII. The leaderboard, podium, and reports filter out `roster_status = 'archived'` so deleted players don't appear. Sufficient for COPPA; full hard-delete deferred.

---

## Raffle History

**Move to database.** New `raffle_winners` table replaces the localStorage source of truth. CASCADE deletes when a player is purged.

**localStorage cleanup:** App boot scans localStorage for any cached raffle data and removes it (since existing test data is being wiped). Going forward, localStorage may be used as a UI cache only — the DB is authoritative.

**"Recent winners" definition:** Configurable, defaults to "winners in the last 30 days." Cleaner than the localStorage "last N entries" approach.

**Scope per spin:** Coach selects which squads are in this spin (multi-select chip, defaults to whichever squad they were just viewing if any).

**Rationale:** Database storage closes the COPPA loophole where a deleted player's name could persist on a coach's device. CASCADE deletion makes purges automatic.

---

## Data Wipe

**All existing data is treated as test data and wiped during Phase 2 migration.** No backfill of historical event-name strings to player UUIDs. No reconciliation UI. Start clean.

**Rationale:** Confirmed during brainstorm. Removes the messiest piece of the migration (name-to-UUID reconciliation) entirely. Phase 1 keeps existing data structure intact — only the wipe happens at Phase 2.

---

## Encryption Posture

- **Transit:** HTTPS-only enforced at hosting provider. HSTS header (`Strict-Transport-Security: max-age=31536000; includeSubDomains`) sent on all responses. Verified once during Phase 1.
- **At rest:** Rely on Supabase's default disk-level encryption (AWS RDS-style).
- **Column-level encryption:** Not added. Not justified by the threat model given how little PII is stored (first name + initial only).

**Privacy policy must document:** What's collected, how long it's kept, the deletion process, the reliance on Supabase's default encryption.

---

## Sort Orders & Display Defaults

- **Squad list:** Grade/age ascending → sort_order → alphabetical. Mixed at bottom.
- **Roster list:** Alphabetical by display name within squad. Archived players hidden.
- **Leaderboard:** Org-wide by default, squad filter chip on the screen. Archived players excluded.
- **Reports:** Org-wide by default with squad filter. When filtered by squad, attendance is computed from events where that squad was in `squad_ids`, regardless of player's current squad.
- **Member list:** Owner first, then Head Coaches alphabetically, then Assistant Coaches alphabetically.

---

## Phasing

**Phase 1 (Foundation):** Multi-tenancy, organizations, invitations, RLS refactor. No new user-visible features.

**Phase 2 (Features):** Squads, COPPA name change, raffle history, player anonymization. Builds on Phase 1.

**Rationale:** Two phases give better Claude Code review quality and let you live with Phase 1 before committing to Phase 2.

---

## What's Out of Scope

- Parent email / Verifiable Parental Consent
- Real email service integration (stubbed in v1)
- Multi-organization users in the UI
- Multi-squad players (use guest mechanism)
- Season grade-advance automation
- Parent/player roles or portals
- Hard delete from archived JSONB snapshots
- Column-level encryption
- Payments / monetization features
